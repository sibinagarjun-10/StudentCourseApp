package com.example.studentapp.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.studentapp.entity.CourseBean;
import com.example.studentapp.exception.AppException;
import com.example.studentapp.repository.CourseRepository;

@Component
public class CourseManager {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentManager enrollmentManager;

    
    public CourseBean findCourseOrThrow(Long courseId) throws AppException {
        return courseRepository.findById(courseId)
                .orElseThrow(() -> AppException.courseNotFound(courseId));
    }

    // ── Validations ───────────────────────────────────────────
    public void checkSeatAvailability(CourseBean course) throws AppException {
        if (course.getAvailableSeats() <= 0) {
        	throw AppException.courseFull(course.getName());
        }
    }

    public void checkNotAlreadyEnrolled(Long studentId, Long courseId) throws AppException {
        if (enrollmentManager.isAlreadyEnrolled(studentId, courseId)) {
        	throw AppException.alreadyEnrolled(courseId); 
        }
    }

    public void checkEnrollmentExists(Long studentId, Long courseId) throws AppException {
        if (!enrollmentManager.isAlreadyEnrolled(studentId, courseId)) {
        	throw AppException.enrollmentNotFound(studentId, courseId);
        }
    }

    // ── Seat management ───────────────────────────────────────
    public void decrementSeat(CourseBean course) {
        course.setAvailableSeats(course.getAvailableSeats() - 1);
        courseRepository.save(course);
    }

    public void incrementSeat(CourseBean course) {
        course.setAvailableSeats(course.getAvailableSeats() + 1);
        courseRepository.save(course);
    }
}