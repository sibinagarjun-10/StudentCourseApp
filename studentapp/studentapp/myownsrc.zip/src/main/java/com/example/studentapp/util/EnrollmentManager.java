package com.example.studentapp.util;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.studentapp.entity.EnrollmentBean;
import com.example.studentapp.repository.EnrollmentRepository;

@Component
public class EnrollmentManager {

    @Autowired
    private EnrollmentRepository enrollmentRepository;

   
    public void saveEnrollment(Long studentId, Long courseId) {
        EnrollmentBean enrollment = new EnrollmentBean();
        enrollment.setStudentId(studentId);
        enrollment.setCourseId(courseId);
        enrollment.setEnrolledAt(new Date());
        enrollmentRepository.save(enrollment);
    }

    
    public boolean isAlreadyEnrolled(Long studentId, Long courseId) {
        return enrollmentRepository
                   .findByStudentIdAndCourseId(studentId, courseId) != null;
    }

   
    public void deleteEnrollment(Long studentId, Long courseId) {
        EnrollmentBean enrollment =
            enrollmentRepository.findByStudentIdAndCourseId(studentId, courseId);
        if (enrollment != null) {
            enrollmentRepository.delete(enrollment);
        }
    }
    
    public List<Long> getEnrolledCourseIds(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                   .stream()
                   .map(EnrollmentBean::getCourseId)
                   .toList();
    }
}
