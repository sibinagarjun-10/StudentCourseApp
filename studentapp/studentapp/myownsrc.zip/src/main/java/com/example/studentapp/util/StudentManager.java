package com.example.studentapp.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.studentapp.dto.RegisterRequest;
import com.example.studentapp.entity.StudentBean;
import com.example.studentapp.exception.AppException;
import com.example.studentapp.repository.StudentRepository;

@Component
public class StudentManager {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private BCryptPasswordEncoder encoder;

    // ── Save ──────────────────────────────────────────────────
    public void saveNewStudent(RegisterRequest request) {
        StudentBean student = new StudentBean();
        student.setName(request.getName());
        student.setEmail(request.getEmail());
        student.setPassword(hashPassword(request.getPassword()));
        student.setCreatedAt(new Date());
        studentRepository.save(student);
    }
    
    public String hashPassword(String rawPassword) {
        return encoder.encode(rawPassword);
    }

    // ── Validations ───────────────────────────────────────────
    public void checkEmailNotTaken(String email) throws AppException {
        if (studentRepository.findByEmail(email) != null) {
        	throw AppException.emailAlreadyRegistered(email); 
        }
    }

    public StudentBean findStudentByEmailOrThrow(String email) throws AppException {
        StudentBean student = studentRepository.findByEmail(email);
        if (student == null) {
        	throw AppException.emailNotFound(email);
        }
        return student;
    }

    public void verifyPasswordOrThrow(String rawPassword, StudentBean student) throws AppException {
        if (!encoder.matches(rawPassword, student.getPassword())) {
        	throw AppException.invalidCredentials();   
        }
    }
}